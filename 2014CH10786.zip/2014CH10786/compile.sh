g++ -std=c++11 -O3 SemanticTree.cpp -o Semantics
g++ -std=c++11 -O3 Resolution.cpp -o Res


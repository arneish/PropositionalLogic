g++ -std=c++11 -O3 SemanticTree.cpp -o Semantics
